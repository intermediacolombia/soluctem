# 🗑️ Sistema de Papelera con Recuperación

## ✨ Características Completas

### 🔄 **Recuperación de Formularios**
- Botón verde "Recuperar Formulario" en vista de eliminado
- Cambia `borrado = 1` a `borrado = 0`
- Limpia `fecha_eliminacion` y `usuario_eliminacion`
- Regresa el formulario al sistema normal

### 📋 **Nuevas Columnas en DataTable**
1. **Fecha Eliminación**: Muestra cuándo fue eliminado (fecha y hora)
2. **Usuario Eliminó**: Muestra quién eliminó el formulario
3. Formato bonito: Badge para usuario, fecha formateada

### 🔐 **Auditoría Completa**
- Se registra quién elimina cada formulario
- Se registra cuándo se elimina
- Se registra quién recupera
- Logs separados para eliminaciones y recuperaciones

## 📁 Archivos del Sistema

### Archivos Principales
1. **papelera_index.php** - Lista de formularios eliminados (con nuevas columnas)
2. **view_deleted.php** - Vista bloqueada + botón recuperar
3. **restore_form.php** - Procesa la recuperación (NUEVO)
4. **delete_updated.php** - Delete mejorado con auditoría (REEMPLAZAR)

### Archivos de Soporte
5. **get_papelera.php** - Carga datos (actualizado con nuevas columnas)
6. **get_filter_options_papelera.php** - Opciones de filtros
7. **get_stats_papelera.php** - Estadísticas
8. **delete_permanent.php** - Eliminación definitiva

### SQL
9. **papelera_migration.sql** - Agregar columnas a la BD (EJECUTAR PRIMERO)

## 🚀 Instalación Paso a Paso

### Paso 1: Actualizar Base de Datos
```sql
-- Ejecutar en MySQL/phpMyAdmin
ALTER TABLE formulario 
ADD COLUMN fecha_eliminacion DATETIME NULL AFTER borrado,
ADD COLUMN usuario_eliminacion VARCHAR(255) NULL AFTER fecha_eliminacion;

ALTER TABLE formulario 
ADD INDEX idx_borrado_fecha (borrado, fecha_eliminacion);
```

### Paso 2: Crear Estructura de Carpetas
```
/admin/
  /papelera/
    - index.php (papelera_index.php)
    - view_deleted.php
    - get_papelera.php
    - get_filter_options_papelera.php
    - get_stats_papelera.php
    - restore_form.php (NUEVO)
    - delete_permanent.php
  /form/
    - delete.php (reemplazar con delete_updated.php)
  /logs/ (crear si no existe)
    - deletions.log (se crea automáticamente)
    - restores.log (se crea automáticamente)
    - permanent_deletions.log (se crea automáticamente)
```

### Paso 3: Permisos de Carpeta Logs
```bash
mkdir /admin/logs
chmod 755 /admin/logs
touch /admin/logs/deletions.log
touch /admin/logs/restores.log
touch /admin/logs/permanent_deletions.log
chmod 644 /admin/logs/*.log
```

### Paso 4: Reemplazar Archivo Delete
```bash
# Backup del delete.php actual
cp /admin/form/delete.php /admin/form/delete.php.backup

# Reemplazar con el nuevo
cp delete_updated.php /admin/form/delete.php
```

### Paso 5: Agregar al Menú
En tu archivo de menú (`inc/menu.php`), agregar:
```php
<?php if ($_SESSION['rol'] === 'Administrador'): ?>
<li>
    <a href="/admin/papelera/">
        <i class="fas fa-trash-alt"></i> Papelera
    </a>
</li>
<?php endif; ?>
```

## 📊 Nuevas Columnas en la Tabla

### Columna: Fecha Eliminación
- **Formato**: dd/mm/yyyy hh:mm
- **Muestra**: 28/01/2026 14:30
- **Color**: Texto normal
- **Si es NULL**: Muestra "-"

### Columna: Usuario Eliminó
- **Formato**: Badge gris con nombre
- **Muestra**: Badge con el nombre del usuario
- **Color**: Gris (badge-secondary)
- **Si es NULL**: Muestra "-"

## 🔄 Flujo de Trabajo

### Eliminar un Formulario
1. Usuario/Admin presiona "Borrar" en un formulario
2. Confirma en el modal
3. Sistema ejecuta:
   ```sql
   UPDATE formulario SET 
     borrado = 1,
     fecha_eliminacion = NOW(),
     usuario_eliminacion = 'Nombre Usuario'
   WHERE id = X
   ```
4. Mensaje: "Formulario movido a papelera"

### Recuperar un Formulario
1. Admin entra a Papelera
2. Click en formulario eliminado
3. Click en "Recuperar Formulario" (botón verde)
4. Confirma en modal
5. Sistema ejecuta:
   ```sql
   UPDATE formulario SET 
     borrado = 0,
     fecha_eliminacion = NULL,
     usuario_eliminacion = NULL
   WHERE id = X
   ```
6. Mensaje: "Formulario recuperado exitosamente"
7. Formulario vuelve al sistema normal

### Eliminar Definitivamente
1. Admin entra a Papelera
2. Click en formulario eliminado
3. Click en "Borrar Definitivamente" (botón rojo)
4. Lee advertencias
5. Confirma en modal
6. Sistema ejecuta:
   ```sql
   DELETE FROM imagenes WHERE formulario_id = X;
   DELETE FROM formulario WHERE id = X AND borrado = 1;
   ```
7. Mensaje: "Formulario eliminado PERMANENTEMENTE"
8. **NO SE PUEDE DESHACER**

## 🎨 Diseño de Botones

### Botón Recuperar (Verde)
```html
<button class="btn btn-success btn-lg">
    <i class="fas fa-trash-restore"></i> Recuperar Formulario
</button>
```
- **Color**: Verde con gradiente
- **Icono**: Basura con flecha de restauración
- **Posición**: Entre "Volver" y "Borrar Definitivamente"

### Modal de Recuperar
- **Header**: Verde con icono
- **Cuerpo**: Icono grande de restauración + info
- **Lista de beneficios**: Qué pasa al recuperar
- **Botones**: Cancelar (gris) + Confirmar (verde)

## 📝 Mensajes del Sistema

### Eliminación a Papelera
```
✓ El formulario #123 (Ticket: TKT-456) ha sido movido a la papelera. 
  Los administradores pueden recuperarlo durante los próximos 3 meses.
```

### Recuperación Exitosa
```
✓ El formulario #123 (Ticket: TKT-456) ha sido recuperado exitosamente.
```

### Eliminación Permanente
```
✓ El formulario #123 ha sido eliminado PERMANENTEMENTE de la base de datos.
```

## 🔍 Logs de Auditoría

### deletions.log
```
Formulario ID 123 movido a papelera por Juan Pérez (juan@example.com) el 2026-01-28 14:30:15
```

### restores.log
```
Formulario ID 123 recuperado de papelera por Admin User (admin@example.com) el 2026-01-28 15:45:22
```

### permanent_deletions.log
```
Formulario ID 123 eliminado PERMANENTEMENTE por Admin User (admin@example.com) el 2026-01-28 16:20:33
```

## 🔐 Permisos

### Usuario Normal
- ✅ Puede eliminar formularios (van a papelera)
- ❌ NO puede ver la papelera
- ❌ NO puede recuperar formularios
- ❌ NO puede eliminar definitivamente

### Administrador
- ✅ Puede eliminar formularios (van a papelera)
- ✅ Puede ver la papelera
- ✅ **Puede recuperar formularios**
- ✅ Puede eliminar definitivamente

## 📊 Vista de Tabla con Nuevas Columnas

```
┌────┬──────────┬────────┬─────────┬────────────┬──────────┬──────────────────────┬──────────────┬──────────┐
│ ID │ Técnico  │ Tienda │ Ticket  │   Fecha    │  Depto   │  Fecha Eliminación   │Usuario Eliminó│ Estado  │
├────┼──────────┼────────┼─────────┼────────────┼──────────┼──────────────────────┼──────────────┼──────────┤
│100 │ Juan P.  │ Norte  │TKT-123  │ 2026-01-15 │ Zona A   │ 28/01/2026 14:30     │ [Juan Pérez] │Eliminado│
│101 │ María G. │ Sur    │TKT-124  │ 2026-01-16 │ Zona B   │ 28/01/2026 15:45     │ [Admin User] │Eliminado│
└────┴──────────┴────────┴─────────┴────────────┴──────────┴──────────────────────┴──────────────┴──────────┘

[Nombre] = Badge gris con el nombre del usuario
```

## 🐛 Solución de Problemas

### Las nuevas columnas no aparecen
```sql
-- Verificar que existan
DESCRIBE formulario;

-- Si no están, ejecutar:
ALTER TABLE formulario 
ADD COLUMN fecha_eliminacion DATETIME NULL,
ADD COLUMN usuario_eliminacion VARCHAR(255) NULL;
```

### Error: "Column 'fecha_eliminacion' cannot be null"
- Asegúrate de que las columnas permitan NULL
- En la migración, usa `NULL` no `NOT NULL`

### Los formularios antiguos no tienen fecha
- Es normal, los eliminados antes de la actualización no tendrán fecha
- Solo los nuevos tendrán la información completa

### El botón de recuperar no funciona
1. Verifica que `restore_form.php` esté en `/admin/papelera/`
2. Verifica permisos del archivo (644)
3. Revisa los logs de PHP para errores

## ✅ Checklist de Implementación

- [ ] Ejecutar SQL de migración (agregar columnas)
- [ ] Crear carpeta `/admin/papelera/`
- [ ] Subir todos los archivos PHP de papelera
- [ ] Crear carpeta `/admin/logs/`
- [ ] Configurar permisos de logs (755 carpeta, 644 archivos)
- [ ] Reemplazar `/admin/form/delete.php` con versión actualizada
- [ ] Agregar enlace a papelera en el menú (solo admin)
- [ ] Probar eliminación (debe guardar fecha y usuario)
- [ ] Probar recuperación (debe limpiar fecha y usuario)
- [ ] Probar eliminación definitiva
- [ ] Verificar logs se crean correctamente

## 🎯 Pruebas Recomendadas

1. **Como Usuario Normal**:
   - Eliminar un formulario
   - Verificar que va a papelera
   - Verificar que NO puede acceder a `/admin/papelera/`

2. **Como Administrador**:
   - Acceder a papelera
   - Ver columnas de fecha y usuario
   - Recuperar un formulario
   - Verificar que vuelve al sistema
   - Eliminar definitivamente
   - Verificar que se borra de BD

3. **Verificar Logs**:
   - Revisar `/admin/logs/deletions.log`
   - Revisar `/admin/logs/restores.log`
   - Revisar `/admin/logs/permanent_deletions.log`

## 📈 Estadísticas

Las estadísticas en la papelera ahora muestran:
- **Total en Papelera**: Todos los formularios con `borrado = 1`
- **Eliminados Hoy**: Los que `fecha_eliminacion` es hoy
- **Esta Semana**: Los que `fecha_eliminacion` está en esta semana

---

**Versión**: 2.0 con Recuperación
**Fecha**: 2026-01-28
**Nueva Funcionalidad**: Recuperar Formularios + Auditoría Completa
