-- SQL para agregar columnas de auditoría de eliminación
-- Ejecutar en la base de datos antes de usar el sistema de papelera

ALTER TABLE formulario 
ADD COLUMN fecha_eliminacion DATETIME NULL AFTER borrado,
ADD COLUMN usuario_eliminacion VARCHAR(255) NULL AFTER fecha_eliminacion;

-- Índice para mejorar las consultas de papelera
ALTER TABLE formulario 
ADD INDEX idx_borrado_fecha (borrado, fecha_eliminacion);

-- Verificar que las columnas se agregaron correctamente
DESCRIBE formulario;
